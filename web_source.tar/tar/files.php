<?php
    echo "<form action='' method='post' enctype='multipart/form-data'>";
    echo "<input type='file' name='file'>";
    echo "<input type='submit' name='submit' value='업로드'>";

    if( isset( $_POST['submit'] ) ) {
        if( isset( $_FILES['file'] ) ) {
            $upload_file_name_tmp = $_FILES['file']['tmp_name'];
            $upload_file_name = $_FILES['file']['name'];
            $upload_dir = 'files/';

            if( strpos( strtolower( $upload_file_name ), "php" ) !== false ) {
                echo "<script>alert('php파일은 업로드 할 수 없습니다!');</script>";
                exit;
            }

            move_uploaded_file( $upload_file_name_tmp, $upload_dir.$upload_file_name );
            echo "<p>".$upload_dir.$upload_file_name."에 업로드 완료.</p>";
        } else {
            echo "<script>alert('대상 파일이 없습니다.');</script>";
        };
    };
?>
