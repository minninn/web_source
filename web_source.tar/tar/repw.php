<?php
    $conn = mysqli_connect(
        'localhost',
        'xss',
        'xss_password',
        'test_login'
    );
    session_start();

    if( isset( $_SESSION['id'] ) ) {
        echo "<form name='change_password' method='post'>";
        echo "<input type='password' name='password' placeholder='이전 비밀번호'>";
        echo "<input type='password' name='change_pw' placeholder='변경할 비밀번호'>";
        echo "<input type='password' name='re_pw' placeholder='변경할 비밀번호 재입력'>";
        echo "<input type='hidden' name='id' value='".$_SESSION["id"]."'>";
        echo "<button name='submit' value='submit'>변경</button></form>";
    } else {
        echo "<script>";
        echo "setTimeout( function() { alert('로그인 후 시도해주세요.'); }, 0 );";
        echo "</script>";
        ob_flush();

        echo "<script>location.replace('index.php');</script>";
        exit;
    };

    if( isset( $_POST["submit"] ) ) {
        $id = $_SESSION['id'];

        if( $_POST['change_pw'] === $_POST['re_pw'] ) {
            $pw = $_POST['change_pw'];
        } else {
            echo "<script>alert('비밀번호를 다시 확인해주세요.');</script>";
            exit;
        };

        $password_query = "SELECT test_pw FROM test_table WHERE test_id = '".$id."';";
        $result = $conn -> query( $password_query );
        $password = mysqli_fetch_array( $result );
        $password = $password[0];

        if( $password === $_POST['password'] ) {
            $change_query = "UPDATE test_table SET test_pw = '".$pw."' WHERE test_id ='".$_POST['id']."';";
            $conn -> query( $change_query );
            session_destroy();

            echo "<script>";
            echo "setTimeout( function() { alert('변경완료'); }, 0 );";
            echo "</script>";
            ob_flush();

            echo "<script>location.replace('index.php');</script>";
            exit;
        } else {
            echo "<script>alert('비밀번호를 다시 확인해주세요.');</script>";
            exit;
        };
    };
?>
