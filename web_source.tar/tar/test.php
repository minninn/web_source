<?php
    $conn = mysqli_connect(
        'localhost',
        'xss',
        'xss_password',
        'test_login'
    );

    $sql = 'SELECT test_id FROM test_table;';
    $result = mysqli_query( $conn, $sql );
    $rows = array();

    while( $row = mysqli_fetch_array( $result ) ) {
        $rows[] = $row;
    };

    foreach( $rows as $key => $row ) {
        echo $row[0]."<br>";
    };


?>
